#pragma once

class Material {
public:
  virtual ~Material();

protected:
  Material();
};
